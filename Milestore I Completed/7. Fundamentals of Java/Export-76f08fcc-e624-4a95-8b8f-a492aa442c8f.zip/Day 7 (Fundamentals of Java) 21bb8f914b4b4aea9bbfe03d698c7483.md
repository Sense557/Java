# Day 7 (Fundamentals of Java)

**Dt - 26 01. 2023 - 27.01.2023**

<aside>
💡 **List of Concepts Involved**

- Statically typed vs Dynamically types PL
- Variables & Data Types
- Type Castin & Truncation
- Naming Convention for variables in java
- Identifiers & Naming Convention
- Introduction of Operators in Java
- Incremention & Decrementation
</aside>

### Give Examples of every primitive datatypes

Sure, here are examples of each data type in Java:

1. byte: used to store small integers from -128 to 127

```
**javaCopy code
byte age = 20;**

```

1. short: used to store small integers from -32,768 to 32,767

```
**javaCopy code
short population = 30000;**

```

1. int: used to store integers from -2,147,483,648 to 2,147,483,647

```
**javaCopy code
int count = 100000;**

```

1. long: used to store larger integers from -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807

```
**javaCopy code
long distance = 10000000000L;**

```

1. float: used to store decimal numbers with 6-7 digits of precision

```
**javaCopy code
float height = 1.75f;**

```

1. double: used to store decimal numbers with 15-16 digits of precision

```
**javaCopy code
double weight = 68.5;**

```

1. char: used to store a single character such as 'a', 'A', '2', or '$'

```
**javaCopy code
char initial = 'J';**

```

1. boolean: used to store true or false values

```
**javaCopy code
boolean isStudent = true;**

```

Note that in the examples above, the variable name and value are just examples and can be replaced with other appropriate names and values.

### Give Examples of every non - Primitive datatypes

**Java has two categories of data types:**

1. **Primitive Data Types:** There are eight primitive data types in Java, which are:
- byte: 8-bit integer
- short: 16-bit integer
- int: 32-bit integer
- long: 64-bit integer
- float: 32-bit floating point
- double: 64-bit floating point
- char: 16-bit Unicode character
- boolean: true/false value

1. **Reference Data Types:** These are non-primitive data types that include arrays, classes, interfaces, and enumerations. They are called reference data types because they hold a reference to an object in memory rather than the value itself. Examples of reference data types are:

```
**javaCopy code
String name = "John"; // String is a reference data type
int[] nums = {1, 2, 3}; // array is a reference data t**

```

---

<aside>
💡 Resource

[Day 7 PPT.pdf](Day%207%20(Fundamentals%20of%20Java)%2021bb8f914b4b4aea9bbfe03d698c7483/Day_7_PPT.pdf)

[Day-7 Lesson Plan.pdf](Day%207%20(Fundamentals%20of%20Java)%2021bb8f914b4b4aea9bbfe03d698c7483/Day-7_LP_compressed.pdf)

</aside>

[Assignment 5 Day 7.pdf](Day%207%20(Fundamentals%20of%20Java)%2021bb8f914b4b4aea9bbfe03d698c7483/Assignment_5_Day_7.pdf)

[Quiz](https://learn.pwskills.com/quiz/Fundamentals-of-Java-quiz/63d39daa0e5fcba7c5850b3e/course/Java-with-DSA-and-system-design/63a2f02d889943137f7ec85f)